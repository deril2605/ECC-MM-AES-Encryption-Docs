[s_box,inv_s_box,poly_mat,inv_poly_mat,rcon]=initialization();
w = key_expansion (key, s_box, rcon, 1);
i=1;enc=[];
sizee=size(y);
kk=dec2hex(floor((((round2((y+1),0.0001))*10000))));
cc=mat2cell(kk,(ones(1,sizee(1))),[2 2]);
cd=cc(:);
pp=size(cd);
while i<pp(1)
ciphertext = cipher ((hex2dec(cd(i:i+15))), w, s_box, poly_mat);
enc=[enc,ciphertext];
i=i+16;
end
encdata=enc';
enc_hex=dec2hex(encdata);
no_one=ones(1,(sizee(1)*2));
op=mat2cell(enc_hex,no_one,[2]);
ret=reshape(op,sizee(1),2);
mat=cell2mat(ret);
againdec=hex2dec(mat);
subtr=(againdec/10000)-1;
