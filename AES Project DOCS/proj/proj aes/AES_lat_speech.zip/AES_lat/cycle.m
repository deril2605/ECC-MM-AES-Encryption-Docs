function out=cycle(m,d)
if strcmp('left',d)
    a=m(1,:);
    b=m(2,:);
    c=m(3,:);
    d=m(4,:);
    e=[b(2),b(3),b(4),b(1)];
    f=[c(3),c(4),c(1),c(2)];
    g=[d(4),d(1),d(2),d(3)];
    out=cat(1,a,e,f,g);
else
    a=m(1,:);
    b=m(2,:);
    c=m(3,:);
    d=m(4,:);
    e=[b(4),b(1),b(2),b(3)];
    f=[c(3),c(4),c(1),c(2)];
    g=[d(2),d(3),d(4),d(1)];
    out=cat(1,a,e,f,g);
end