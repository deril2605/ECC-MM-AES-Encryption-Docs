function varargout = process_decrypt(varargin)
% PROCESS_DECRYPT M-file for process_decrypt.fig
%      PROCESS_DECRYPT, by itself, creates a new PROCESS_DECRYPT or raises the existing
%      singleton*.
%
%      H = PROCESS_DECRYPT returns the handle to a new PROCESS_DECRYPT or the handle to
%      the existing singleton*.
%
%      PROCESS_DECRYPT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROCESS_DECRYPT.M with the given input arguments.
%
%      PROCESS_DECRYPT('Property','Value',...) creates a new PROCESS_DECRYPT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before process_decrypt_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to process_decrypt_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help process_decrypt

% Last Modified by GUIDE v2.5 13-Oct-2011 22:00:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @process_decrypt_OpeningFcn, ...
                   'gui_OutputFcn',  @process_decrypt_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before process_decrypt is made visible.
function process_decrypt_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to process_decrypt (see VARARGIN)

% Choose default command line output for process_decrypt
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes process_decrypt wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = process_decrypt_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in dec_file.
function dec_file_Callback(hObject, eventdata, handles)
% global w
% global inv_s_box
% global inv_poly_mat
% global sizee
% global no_one
wait
load var_save.mat
decrypt
wavwrite(subtr_r,8000,'decrypted.wav');
dec_show
close(wait)
% hObject    handle to dec_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in exit.
function exit_Callback(hObject, eventdata, handles)
close(process_decrypt)
voice_Encryption
% hObject    handle to exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in chose.
function chose_Callback(hObject, eventdata, handles)
global fname
[fname,pathname] = uigetfile('*.txt','Select a key file ....');
set(handles.display,'string',fname);
% hObject    handle to chose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function display_Callback(hObject, eventdata, handles)
% hObject    handle to display (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of display as text
%        str2double(get(hObject,'String')) returns contents of display as a double


% --- Executes during object creation, after setting all properties.
function display_CreateFcn(hObject, eventdata, handles)
% hObject    handle to display (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in browse.
function browse_Callback(hObject, eventdata, handles)
global filename
[filename,pathname] = uigetfile('*.wav','Select a wav file ....');
set(handles.search,'string','Encrypted File loaded');
% hObject    handle to browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in remove.
function remove_Callback(hObject, eventdata, handles)
set(handles.search,'string','Please search file encrypt');
% hObject    handle to remove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in search.
function search_Callback(hObject, eventdata, handles)
% hObject    handle to search (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns search contents as cell array
%        contents{get(hObject,'Value')} returns selected item from search


% --- Executes during object creation, after setting all properties.
function search_CreateFcn(hObject, eventdata, handles)
% hObject    handle to search (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


