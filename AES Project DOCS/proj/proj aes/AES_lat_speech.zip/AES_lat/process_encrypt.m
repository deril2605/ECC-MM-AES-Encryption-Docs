function varargout = process_encrypt(varargin)
% PROCESS_ENCRYPT M-file for process_encrypt.fig
%      PROCESS_ENCRYPT, by itself, creates a new PROCESS_ENCRYPT or raises the existing
%      singleton*.
%
%      H = PROCESS_ENCRYPT returns the handle to a new PROCESS_ENCRYPT or the handle to
%      the existing singleton*.
%
%      PROCESS_ENCRYPT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROCESS_ENCRYPT.M with the given input arguments.
%
%      PROCESS_ENCRYPT('Property','Value',...) creates a new PROCESS_ENCRYPT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before process_encrypt_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to process_encrypt_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help process_encrypt

% Last Modified by GUIDE v2.5 13-Oct-2011 21:12:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @process_encrypt_OpeningFcn, ...
                   'gui_OutputFcn',  @process_encrypt_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before process_encrypt is made visible.
function process_encrypt_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to process_encrypt (see VARARGIN)

% Choose default command line output for process_encrypt
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes process_encrypt wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = process_encrypt_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in encryptFile.
function encryptFile_Callback(hObject, eventdata, handles)
global fname
global filename
global i
fid=fopen(fname,'r');
key= fscanf(fid, '%d');
if(i==1)
    [y,Fs]=wavread(filename);
else
    [y,Fs]=wavread('Original.wav');
end
wait
encrypt
save var_save encdata w inv_s_box inv_poly_mat sizee no_one
wavwrite(subtr,8000,'Encrypted.wav');
disp_enc
close(wait)
% encrypt
% hObject    handle to encryptFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in exit.
function exit_Callback(hObject, eventdata, handles)
close(process_encrypt)
voice_Encryption
% hObject    handle to exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in chose.
function chose_Callback(hObject, eventdata, handles)
global fname
[fname,pathname] = uigetfile('*.txt','Select a key file ....');
set(handles.display_chose,'string',fname);
% hObject    handle to chose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



%        str2double(get(hObject,'String')) returns contents of display_chose as a double


% --- Executes during object creation, after setting all properties.
function display_chose_CreateFcn(hObject, eventdata, handles)
% hObject    handle to display_chose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in add.
function add_Callback(hObject, eventdata, handles)
AddDatabase
set(handles.display,'string','voice loaded');
% hObject    handle to add (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in remov.
function remov_Callback(hObject, eventdata, handles)
set(handles.display,'string','your Database is empty');
% hObject    handle to remov (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in display.
function display_Callback(hObject, eventdata, handles)

% hObject    handle to display (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns display contents as cell array
%        contents{get(hObject,'Value')} returns selected item from display


% --- Executes during object creation, after setting all properties.
function display_CreateFcn(hObject, eventdata, handles)
% hObject    handle to display (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
% --- Executes during object creation, after setting all properties.
function dis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


