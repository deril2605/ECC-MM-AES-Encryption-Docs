function varargout = voice_Encryption(varargin)
% VOICE_ENCRYPTION M-file for voice_Encryption.fig
%      VOICE_ENCRYPTION, by itself, creates a new VOICE_ENCRYPTION or raises the existing
%      singleton*.
%
%      H = VOICE_ENCRYPTION returns the handle to a new VOICE_ENCRYPTION or the handle to
%      the existing singleton*.
%
%      VOICE_ENCRYPTION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VOICE_ENCRYPTION.M with the given input arguments.
%
%      VOICE_ENCRYPTION('Property','Value',...) creates a new VOICE_ENCRYPTION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before voice_Encryption_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to voice_Encryption_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help voice_Encryption

% Last Modified by GUIDE v2.5 12-Oct-2011 23:11:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @voice_Encryption_OpeningFcn, ...
                   'gui_OutputFcn',  @voice_Encryption_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before voice_Encryption is made visible.
function voice_Encryption_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to voice_Encryption (see VARARGIN)

% Choose default command line output for voice_Encryption
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes voice_Encryption wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = voice_Encryption_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes on button press in encryption_main.
function encryption_main_Callback(hObject, eventdata, handles)
close(voice_Encryption)
process_encrypt
% hObject    handle to encryption_main (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in decryption_main.
function decryption_main_Callback(hObject, eventdata, handles)
close(voice_Encryption)
process_decrypt
% hObject    handle to decryption_main (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in exit_main.
function exit_main_Callback(hObject, eventdata, handles)
close(voice_Encryption)
close(dec_show)
close(disp_enc)
close(disp_original)
close(help)
% hObject    handle to exit_main (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function picture_CreateFcn(hObject, eventdata, handles)
h = imshow('abc.jpg');
im = imagemodel(h);
% hObject    handle to picture (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate picture


% --- Executes on button press in help.
function help_Callback(hObject, eventdata, handles)
help
% hObject    handle to help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


