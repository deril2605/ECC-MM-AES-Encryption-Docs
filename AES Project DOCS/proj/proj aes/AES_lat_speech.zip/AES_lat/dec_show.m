function varargout = dec_show(varargin)
% DEC_SHOW M-file for dec_show.fig
%      DEC_SHOW, by itself, creates a new DEC_SHOW or raises the existing
%      singleton*.
%
%      H = DEC_SHOW returns the handle to a new DEC_SHOW or the handle to
%      the existing singleton*.
%
%      DEC_SHOW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DEC_SHOW.M with the given input arguments.
%
%      DEC_SHOW('Property','Value',...) creates a new DEC_SHOW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before dec_show_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to dec_show_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help dec_show

% Last Modified by GUIDE v2.5 13-Oct-2011 22:25:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @dec_show_OpeningFcn, ...
                   'gui_OutputFcn',  @dec_show_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before dec_show is made visible.
function dec_show_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to dec_show (see VARARGIN)

% Choose default command line output for dec_show
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes dec_show wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = dec_show_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in click.
function click_Callback(hObject, eventdata, handles)
y = wavread('decrypted.wav');
wavplay(y,8000)
plot(y)
figure(3)
Fs=8000;
psdest = psd(spectrum.periodogram,y,'Fs',Fs);
plot(psdest)
% psddec

% hObject    handle to click (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


