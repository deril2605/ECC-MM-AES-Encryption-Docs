function w_out = rot_word (w_in)
w_out = w_in([2 3 4 1]);