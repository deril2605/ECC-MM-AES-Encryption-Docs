v_size=size(encdata);
i=1;ecip=[];
while i<v_size(1)
ciphertext=encdata(i:i+15);
re_plaintext = inv_cipher (ciphertext, w, inv_s_box, inv_poly_mat, 1);
ecip=[ecip,re_plaintext];
i=i+16;
end
recover_plain=ecip';
plainn_hex=dec2hex(recover_plain);
op_r=mat2cell(plainn_hex,no_one,[2]);
ret_r=reshape(op_r,sizee(1),2);
mat_r=cell2mat(ret_r);
againdec_r=hex2dec(mat_r);
divide_r=againdec_r/10000;
subtr_r=divide_r-1;
